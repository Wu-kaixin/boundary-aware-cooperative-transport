Final analysis is separate from frozen simulation source. Set PYTHONPATH to analysis_source/src. See bundle README.md for compact-input materialization and reproduction.
